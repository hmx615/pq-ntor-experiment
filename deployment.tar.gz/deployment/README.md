# PQ-Tor 飞腾派部署辅助文件

这个目录包含在飞腾派上部署PQ-Tor之前的验证工具。

## 📦 文件说明

| 文件 | 用途 |
|------|------|
| `check_env.sh` | 环境检查脚本，验证系统依赖 |
| `test_kyber_simple.c` | Kyber KEM验证程序 |
| `Makefile` | 编译验证程序的Makefile |
| `install_deps.sh` | 自动安装依赖脚本 |
| `README.md` | 本文件 |

## 🚀 快速开始

### 步骤1: 传输文件到飞腾派

```bash
# 在开发机上（WSL）
cd /home/ccc/pq-ntor-experiment
scp -r deployment user@192.168.1.10:~/pq-tor-deployment

# 或使用tar打包传输
tar czf deployment.tar.gz deployment/
scp deployment.tar.gz user@192.168.1.10:~/
```

在飞腾派上解压：
```bash
cd ~
tar xzf deployment.tar.gz
cd deployment/
```

### 步骤2: 运行环境检查

```bash
chmod +x check_env.sh
./check_env.sh
```

**预期输出**: 全部显示 ✅

如果有 ❌，按照提示安装缺失的依赖：
```bash
sudo apt-get update
sudo apt-get install build-essential cmake libssl-dev git
```

### 步骤3: 安装liboqs

```bash
chmod +x install_deps.sh
./install_deps.sh
```

这将自动：
1. 克隆liboqs源码
2. 编译liboqs（针对ARM64优化）
3. 安装到 ~/oqs 目录

**预计时间**: 5-10分钟（取决于飞腾派性能）

### 步骤4: 运行Kyber验证程序

```bash
make
./test_kyber_simple
```

**预期输出**:
```
======================================
  飞腾派Kyber KEM验证程序
======================================

[1/4] 检查Kyber512算法...
      ✅ Kyber512可用

[2/4] 创建KEM对象...
      ✅ KEM对象创建成功
      公钥大小: 800 bytes
      密钥大小: 1632 bytes
      密文大小: 768 bytes
      共享密钥: 32 bytes

[3/4] 生成密钥对...
      ✅ 密钥对生成成功

[4/4] 测试封装/解封装...
      ✅ 封装成功
      ✅ 解封装成功
      ✅ 共享密钥匹配

======================================
  ✅ 所有测试通过！
  飞腾派环境配置成功！
  可以开始编译完整PQ-Tor代码！
======================================
```

## ✅ 验证成功后

如果看到上述输出，说明飞腾派环境**完全就绪**！

接下来可以：
1. 传输完整PQ-Tor代码到飞腾派
2. 修改Makefile中的liboqs路径为 `$HOME/oqs`
3. 编译完整项目：`make all`
4. 运行测试：`./test_network.sh`

## 🐛 常见问题

### Q: check_env.sh 报告缺少依赖
**A**: 运行安装命令
```bash
sudo apt-get install build-essential cmake libssl-dev git
```

### Q: 编译test_kyber_simple时找不到oqs/oqs.h
**A**: 确认liboqs安装到了 ~/oqs，检查路径：
```bash
ls ~/oqs/include/oqs/
```

### Q: 运行test_kyber_simple时找不到liboqs.so
**A**: 设置库路径：
```bash
export LD_LIBRARY_PATH=$HOME/oqs/lib:$LD_LIBRARY_PATH
./test_kyber_simple
```

或者编译时使用-rpath（Makefile已包含）

## 📞 需要帮助？

参考完整部署指南：`../飞腾派部署指南.md`

---

**创建时间**: 2025-11-06
**适用平台**: 飞腾派 (ARM64)
**验证策略**: 分步验证，确保每步成功后再进行下一步
