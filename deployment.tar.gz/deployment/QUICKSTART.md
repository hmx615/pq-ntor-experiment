# 🚀 飞腾派部署快速开始

5分钟验证飞腾派环境是否就绪！

## 📦 第一步：传输文件

### 方式1: 使用 scp（推荐）

```bash
# 在WSL开发机上
cd /home/ccc/pq-ntor-experiment
scp deployment.tar.gz pi@192.168.1.10:~/
```

### 方式2: 使用U盘

```bash
# 拷贝 deployment.tar.gz 到U盘
cp deployment.tar.gz /mnt/usb/

# 在飞腾派上拷贝
cp /media/usb/deployment.tar.gz ~/
```

## 📂 第二步：解压文件

```bash
# SSH登录飞腾派
ssh pi@192.168.1.10

# 解压
cd ~
tar xzf deployment.tar.gz
cd deployment/

# 查看文件
ls -la
```

应该看到以下文件：
- `check_env.sh` - 环境检查脚本
- `install_deps.sh` - 自动安装liboqs
- `test_kyber_simple.c` - Kyber验证程序
- `Makefile` - 编译配置
- `README.md` - 详细说明
- `QUICKSTART.md` - 本文件

## ✅ 第三步：检查环境

```bash
chmod +x check_env.sh
./check_env.sh
```

### 预期输出（全部✅）：
```
======================================
  飞腾派环境检查
======================================

[1/8] 检查CPU架构...
      架构: aarch64
      ✅ ARM64架构正确

[2/8] 检查操作系统...
      OS: Ubuntu 22.04
      ✅ Linux系统

[3/8] 检查GCC编译器...
      gcc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
      ✅ GCC已安装

[4/8] 检查Make...
      GNU Make 4.3
      ✅ Make已安装

[5/8] 检查CMake...
      cmake version 3.22.1
      ✅ CMake已安装

[6/8] 检查OpenSSL...
      OpenSSL 3.0.2 15 Mar 2022
      ✅ OpenSSL开发库已安装

[7/8] 检查Git...
      git version 2.34.1
      ✅ Git已安装

[8/8] 检查磁盘空间...
      可用空间: 5.2G
      需要空间: ~500MB
      ✅ 磁盘空间检查完成

======================================
  ✅ 环境检查通过！
======================================
```

### 如果有❌：安装缺失依赖

```bash
sudo apt-get update
sudo apt-get install -y build-essential cmake libssl-dev git
```

然后重新运行 `./check_env.sh`

## 🔨 第四步：安装 liboqs

```bash
chmod +x install_deps.sh
./install_deps.sh
```

这将自动完成：
1. 克隆 liboqs 源码
2. 针对 ARM64 编译（使用所有CPU核心）
3. 安装到 ~/oqs 目录

**预计时间**: 5-10分钟

### 预期输出（最后几行）：
```
======================================
  ✅ liboqs 安装成功！
======================================

安装位置:
  库文件: /home/pi/oqs/lib/liboqs.so
  头文件: /home/pi/oqs/include/oqs/

下一步:
  1. 编译测试程序: make
  2. 运行验证: ./test_kyber_simple
```

## 🧪 第五步：运行 Kyber 验证程序

```bash
make
./test_kyber_simple
```

### 🎉 成功标志：

```
======================================
  飞腾派Kyber KEM验证程序
======================================

[1/4] 检查Kyber512算法...
      ✅ Kyber512可用

[2/4] 创建KEM对象...
      ✅ KEM对象创建成功
      公钥大小: 800 bytes
      密钥大小: 1632 bytes
      密文大小: 768 bytes
      共享密钥: 32 bytes

[3/4] 生成密钥对...
      ✅ 密钥对生成成功

[4/4] 测试封装/解封装...
      ✅ 封装成功
      ✅ 解封装成功
      ✅ 共享密钥匹配

======================================
  ✅ 所有测试通过！
  飞腾派环境配置成功！
  可以开始编译完整PQ-Tor代码！
======================================
```

**如果看到这个输出 = 飞腾派环境100%就绪！**

## 🎯 第六步：部署完整 PQ-Tor 代码

环境验证成功后，就可以部署完整代码了：

```bash
# 传输完整代码到飞腾派
cd ~
# 使用 scp 或 git clone 获取完整代码

# 进入项目目录
cd pq-ntor-experiment/c

# 修改 Makefile（如果需要）
# 将 LIBOQS_DIR = $(HOME)/_oqs 改为 LIBOQS_DIR = $(HOME)/oqs

# 编译所有程序
make all

# 运行单元测试
./test_kyber
./test_crypto
./test_pq_ntor
./test_cell
./test_onion

# 所有测试应该输出: ✅ All tests passed!

# 运行完整网络测试（单机5进程）
./test_network.sh
```

## 📊 检查清单

在**每个飞腾派**上完成以下步骤：

- [ ] 传输 deployment.tar.gz 到飞腾派
- [ ] 解压文件
- [ ] 运行 check_env.sh（全部✅）
- [ ] 运行 install_deps.sh（安装liboqs）
- [ ] 运行 test_kyber_simple（验证成功）
- [ ] 传输完整PQ-Tor代码
- [ ] 编译完整项目（make all）
- [ ] 运行所有单元测试（全部通过）
- [ ] （仅派1）运行 test_network.sh

## 🌐 5节点分布式部署

全部5个派验证通过后，参考 `飞腾派部署指南.md` 的 Step 6 进行分布式部署。

### 节点分配：

| 派编号 | IP | 角色 | 启动命令 |
|--------|------------|------|----------|
| 派1 | 192.168.1.10 | Directory | `./directory` |
| 派2 | 192.168.1.11 | Guard | `./relay -r guard -p 6001` |
| 派3 | 192.168.1.12 | Middle | `./relay -r middle -p 6002` |
| 派4 | 192.168.1.13 | Exit | `./relay -r exit -p 6003` |
| 派5 | 192.168.1.14 | Client | `./client http://192.168.1.10:8000` |

## 🐛 遇到问题？

### Q: check_env.sh 报告缺少依赖
**A**:
```bash
sudo apt-get update
sudo apt-get install -y build-essential cmake libssl-dev git
```

### Q: install_deps.sh 编译失败
**A**: 检查网络连接，可能是 git clone 失败。手动下载：
```bash
cd ~/pq-tor-deps
wget https://github.com/open-quantum-safe/liboqs/archive/refs/tags/0.11.0.tar.gz
tar xzf 0.11.0.tar.gz
cd liboqs-0.11.0
# 然后按照 install_deps.sh 中的步骤手动编译
```

### Q: test_kyber_simple 运行时找不到 liboqs.so
**A**:
```bash
export LD_LIBRARY_PATH=$HOME/oqs/lib:$LD_LIBRARY_PATH
./test_kyber_simple
```

或者重新编译（Makefile 已包含 -rpath）

### Q: 需要在所有5个派上都运行这些步骤吗？
**A**: 是的！每个派都需要完整的环境和代码。

## 📞 需要更多帮助？

查看完整文档：
- `README.md` - 本目录的详细说明
- `../飞腾派部署指南.md` - 完整部署方案
- `../c/README.md` - PQ-Tor 项目主文档

---

**预计总时间**: 每个飞腾派 20-30分钟

**成功标志**: test_kyber_simple 全部显示 ✅

**下一步**: 部署完整5节点PQ-Tor网络

---

**创建时间**: 2025-11-06
**版本**: 1.0
**适用平台**: 飞腾派 ARM64
